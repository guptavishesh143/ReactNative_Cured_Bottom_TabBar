const Images = {
  icons: {
    home: require('./Home.png'),
    homeFocused: require('./Home_focused.png'),
    Map:require('./Map.png'),
    MapFocused:require('./MapFocused.png'),
    Chat:require('./Chat.png'),
    ChatFocused:require('./ChatFocused.png'),
    Settings: require('./Settings.png'),
    SettingsFocused: require('./SettingsFocused.png'),
    
  },
};

export default Images;
