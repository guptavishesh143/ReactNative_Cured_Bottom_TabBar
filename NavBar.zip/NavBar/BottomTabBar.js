// Imported Libraries
import * as React from 'react';
import {useState, useEffect} from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {View, Image, Text, StatusBar} from 'react-native';
import TabComponent from './Comp/TabComponent';
// Importing Screen Files
import Home from '../../screens/MainScreen/Home';
import Map from '../../screens/MainScreen/Map';
import Settings from '../../screens/MainScreen/Settings';
import Chat from '../../screens/MainScreen/Chat';
import {scale, moderateScale, verticalScale} from '../../../Scaling_utils';
import ActivateChip from '../../screens/MainScreen/ActivateChip';
import MyInfo from '../../screens/MainScreen/MyInfo';
import WebViewScreen from "../../screens/MainScreen/WebViewScreen"
import TermCondition from '../../screens/MainScreen/TermCondition';

const BackButn = () => {
  return (
    <View style={{paddingLeft: 16, marginTop: 30}}>
      {/* Image in the form of Jsx Components */}
      <Image
        style={{height: 38, width: 38}}
        resizeMode={'contain'}
        source={require('../../assets/BackBtn.png')}
      />
    </View>
  );
};

const MyinfoLeft = () => {
	return (

		<>
    <View style={{flexDirection:"row",paddingHorizontal:10}}>
    <View style={{paddingLeft: 16, marginTop: 30}}>
			<Image
				source={require("../../assets/Filter.png")}
        style={{height: 38, width: 38}}
        resizeMode={'contain'}
			/>
		</View>
    <View style={{paddingLeft: 16, marginTop: 30}}>
			<Image
				source={require("../../assets/Plus.png")}
        style={{height: 38, width: 38}}
        resizeMode={'contain'}
			/>
		</View>
    </View>
    </>
    
	);
};

const CancelBtn = () => {
	return (
		<View style={{paddingHorizontal: 16}}>
			<Image
				resizeMode={'contain'}
				source={require('../../assets/cancel.png')}
				style={{height: 18, width: 18}}
			/>
		</View>
	);
};
//Function for Stack Navigator
function BottomTabBar({navigation}) {
  const [user, setUser] = useState();

  //Bottom TabBar Function
  const Tab = createBottomTabNavigator();
  const LoggedInStack = createStackNavigator();
  const LoginStack = createStackNavigator();



  const LoggedStack = () => {
    return (
      <LoggedInStack.Navigator
        screenOptions={{
          headerStyle: {backgroundColor: 'white'},
          headerTintColor: '#fff',
          headerTitleStyle: {fontWeight: 'bold'},
          headerShown: false,
        }}>
        <LoggedInStack.Screen
          name="Home"
          component={HomeTabs}
          options={{
            title: ' ',
            headerStyle: {},
            headerTransparent: true,
          }}
        />
        <LoggedInStack.Screen
          name="Homes"
          component={Home}
          options={{
            title: ' ',
            headerStyle: {},
            headerTransparent: true,
          }}
        />
        <LoggedInStack.Screen
          name="Map"
          component={Map}
          options={{
            title: ' ',
            headerStyle: {},
            headerTransparent: true,
          }}
        />
           <LoggedInStack.Screen
          name="ActivateChip"
          component={ActivateChip}
          options={{
            title: ' ',
            headerStyle: {},
            headerTransparent: true,
          }}
        />
             <LoggedInStack.Screen
          name="MyInfo"
          component={MyInfo}
          options={{
            headerShown: true,
            gesturesEnabled: false,
            headerBackImage: BackButn,
            headerTransparent: true,
            headerTitle: ' ',
          headerRight:MyinfoLeft
          }}
        />
           <LoggedInStack.Screen
          name="WebViewScreen"
          component={WebViewScreen}
          options={{
						title: 'TapChats.com',
            headerTitleStyle:{
           
            },
						headerStyle: {
							backgroundColor: '#00041E',
						},
						headerShown: true,
						headerBackImage: CancelBtn,
					}}
        />
           <LoggedInStack.Screen
          name="TermCondition"
          component={TermCondition}
          options={{
						title: 'Term & Condition',
          
						headerStyle: {
							backgroundColor: '#00041E',
						},
						headerShown: true,
						headerBackImage: CancelBtn,
					}}
        />
      </LoggedInStack.Navigator>
    );
  };

  //Supporting BottomTabS
  const HomeTabs = () => {
    return (
      <Tab.Navigator
        tabBarOptions={{
          showIcon: true,
          showLabel: false,
          style: {
            backgroundColor: 'white',
            borderTopWidth: 0,
            position: 'absolute',
            keyboardHidesTabBar: true,
            position: 'absolute',
            height: verticalScale(60),
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
            paddingTop: verticalScale(6),
          },
        }}>
        {/* HomeScreen BottomTabBar */}
        <Tab.Screen
          name="Homes"
          component={Home}
          options={{
            tabBarButton: props => <TabComponent label="home" {...props} />,
          }}
        />
        {/* DashBoardScreen BottomTabBar */}
        <Tab.Screen
          name="Map"
          component={Map}
          options={{
            tabBarButton: props => <TabComponent label="Map" {...props} />,
          }}
        />
        {/* MarketScreen BottomTabBar */}

        <Tab.Screen
          name="Chat"
          component={Chat}
          options={{
            tabBarButton: props => <TabComponent label="Chat" {...props} />,
          }}
        />
        <Tab.Screen
          name="Setting"
          component={Settings}
          options={{
            tabBarButton: props => <TabComponent label="Settings" {...props} />,
          }}
        />
      </Tab.Navigator>
    );
  };

  // if (!user) {
    return (
      <>
        <StatusBar barStyle="light-content" />
        <NavigationContainer>
          <LoggedStack />
        </NavigationContainer>
      </>)

}

export default BottomTabBar;
