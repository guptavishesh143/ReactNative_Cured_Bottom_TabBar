// Imported React Libraries

import React from 'react';
import styled from 'styled-components/native';
import Images from '../Img';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  Image

} from 'react-native';

// Importing Screen Files and Neccesary Components

function Tab({label, accessibilityState, onPress}) {
  const focused = accessibilityState.selected;
  const icon = !focused ? Images.icons[label] : Images.icons[`${label}Focused`];
  return (
    // <View style={{backgroundColor:"red"}}>
    <Container onPress={onPress}>
      <Background focused={focused}>
      <Icon source={icon} label={label} />
      </Background>
    </Container>
    // </View>
  );
}

const Container = styled.TouchableWithoutFeedback``;
const Background = styled.View`
  flex: auto;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  `;
const Icon = styled.Image`

  height: ${(props) => (props.focused ? '16px' : '16px')};
  width: ${(props) => (props.focused ? '16px' : '16px')};
`;

export default Tab;
